<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>404 ko tìm thấy</title>
</head>
<body>
	<style>
		body{
			background: #ddd;
			text-align: center;
		}
	</style>
	<h1>404 ko tìm thấy</h1>
</body>
</html>