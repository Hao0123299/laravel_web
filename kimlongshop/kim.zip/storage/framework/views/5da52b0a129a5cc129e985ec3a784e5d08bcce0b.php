<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Gửi mail google</title>
</head>
<body>
	<h1>Mail được gửi từ : <?php echo e($name); ?></h1>
	<h4>Với nội dung : <?php echo e($body); ?></h4>
</body>
</html><?php /**PATH D:\xampp\htdocs\tutorial_youtube\shopbanhanglaravel\resources\views/pages/send_mail.blade.php ENDPATH**/ ?>