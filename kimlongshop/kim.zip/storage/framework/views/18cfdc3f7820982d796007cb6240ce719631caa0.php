<?php $__env->startSection('admin_content'); ?>
<h3><center>Chào mừng bạn đến với đồ án hướng dẫn website của anh Hiếu nhé</center></h3>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xam\htdocs\baocaotn\kimlongshop\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>